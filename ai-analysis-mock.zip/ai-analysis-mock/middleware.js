module.exports = function (req, res, next) {
    console.log(req.headers);
    console.log(req.method);
    console.log(req.body);

    if (req.method === 'POST') {
        req.method = 'GET'
        
        if (req.body.image_path.includes('error.jpg')) {
           req.url = '/fail';
        } else {
           req.url = '/success'; 
        }
    }
    
    next()
}