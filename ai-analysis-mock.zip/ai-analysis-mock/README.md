# API mock-up

## 概要
「特定の画像ファイルへのPathを与えると、AIで分析し、その画像が所属するClassを返却するAPI」のmock-upです。

## 使用方法
* 圧縮ファイル(ai-analysis-mock.zip)を解凍
* 解凍したファイルで、下記コマンドを実行し、json-serverの立ち上げを実施
```
$ npx json-server --watch db.json -p 3000 --host 127.0.0.1 --middlewares middleware.js
```
* 立ち上がったらAPIの使用が可能状態に

|リクエストURL|リクエストボディ|レスポンス|
|---|---|---|
|http://127.0.0.1:3000|{"image_path": "/image/d03f1d36ca69348c51aa/c413eac329e1c0d03/test.jpg"}|リクエスト成功|
|http://127.0.0.1:3000|{"image_path": "/image/d03f1d36ca69348c51aa/c413eac329e1c0d03/error.jpg"}|リクエスト失敗|